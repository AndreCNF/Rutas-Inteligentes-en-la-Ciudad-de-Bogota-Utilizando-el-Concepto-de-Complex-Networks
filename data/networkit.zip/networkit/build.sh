rm _NetworKit.cpp
python3 setup.py clean
python3 setup.py build_ext --inplace

