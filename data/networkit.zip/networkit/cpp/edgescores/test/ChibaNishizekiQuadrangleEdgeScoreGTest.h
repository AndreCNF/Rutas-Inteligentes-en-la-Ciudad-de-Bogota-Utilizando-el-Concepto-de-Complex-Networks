/*
 * ChibaNishizekiQuadrangleEdgeScoreGTest.h
 *
 *  Created on: 23.05.2014
 *      Author: Gerd Lindner
 */

#ifndef NOGTEST

#ifndef CHIBANISHIZEKITEST_H_
#define CHIBANISHIZEKITEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class ChibaNishizekiQuadrangleEdgeScoreGTest: public testing::Test {

};


} /* namespace NetworKit */
#endif /* CHIBANISHIZEKITEST_H_ */

#endif /*NOGTEST */
