/*
 * APSPGTest.h
 *
 *  Created on: 07.07.2015
 *      Author: Arie Slobbe
 */

#ifndef NOGTEST

#ifndef APSPGTEST_H_
#define APSPGTEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class APSPGTest: public testing::Test {
};

} /* namespace NetworKit */

#endif /* APSPGTEST_H_ */

#endif /* NOGTEST */
