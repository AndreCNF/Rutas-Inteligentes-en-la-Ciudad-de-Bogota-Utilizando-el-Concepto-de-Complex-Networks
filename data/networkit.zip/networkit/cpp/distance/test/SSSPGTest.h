/*
 * DynSSSPGTest.h
 *
 *  Created on: 21.07.2014
 *      Author: ebergamini
 */

#ifndef SSSPGTEST_H_
#define SSSPGTEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class SSSPGTest: public testing::Test {
};

} /* namespace NetworKit */

#endif /* SSSPGTEST_H_ */
