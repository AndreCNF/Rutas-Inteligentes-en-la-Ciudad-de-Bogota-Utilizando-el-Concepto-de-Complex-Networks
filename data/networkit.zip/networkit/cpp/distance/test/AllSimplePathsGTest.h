/*
 * AllSimplePathsGTest.h
 *
 *  Created on: 26.06.2017
 *      Author: Eugenio Angriman
 */

#ifndef NOGTEST

#ifndef ALLSIMPLEPATHSGTEST_H_
#define ALLSIMPLEPATHSGTEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class AllSimplePathsGTest: public testing::Test {
};

} /* namespace NetworKit */

#endif /* ALLSIMPLEPATHSGTEST_H_ */

#endif /* NOGTEST */
