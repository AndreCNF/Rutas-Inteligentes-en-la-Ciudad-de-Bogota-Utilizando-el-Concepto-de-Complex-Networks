/*
 * DistanceGTest.h
 *
 *  Created on: Sep 04, 2015
 *      Author: maxv
 */

#ifndef NOGTEST

#ifndef DISTANCEGTEST_H_
#define DISTANCEGTEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class DistanceGTest: public testing::Test {
public:
};

} /* namespace NetworKit */
#endif /* DISTANCEGTEST_H_ */

#endif /*NOGTEST */
