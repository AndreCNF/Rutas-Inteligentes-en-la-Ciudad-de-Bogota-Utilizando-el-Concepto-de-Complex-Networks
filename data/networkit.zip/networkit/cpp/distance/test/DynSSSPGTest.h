/*
 * DynSSSPGTest.h
 *
 *  Created on: 21.07.2014
 *      Author: ebergamini
 */

#ifndef DYNSSSPGTEST_H_
#define DYNSSSPGTEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class DynSSSPGTest: public testing::Test {
};

} /* namespace NetworKit */

#endif /* DYNSSSPGTEST_H_ */
