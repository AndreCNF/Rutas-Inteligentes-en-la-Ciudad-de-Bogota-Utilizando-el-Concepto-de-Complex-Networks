/*
 * NodeDistance.cpp
 *
 *  Created on: 18.06.2013
 *      Author: cls
 */

#include "NodeDistance.h"

namespace NetworKit {

NodeDistance::NodeDistance(const Graph& G) : G(G) {
	// TODO Auto-generated constructor stub

}

} /* namespace NetworKit */
