/*
 * ApproxBetweenness2.h
 *
 *  Created on: 03.05.2017
 *      Author: kesders
 */

#ifndef APPROXBETWEENNESS2_H_
#define APPROXBETWEENNESS2_H_


namespace NetworKit {

typedef EstimateBetweenness ApproxBetweenness2 __attribute__((deprecated("Use EstimateBetweenness instead.")));

} /* namespace NetworKit */

#endif /* APPROXBETWEENNESS2_H_ */
