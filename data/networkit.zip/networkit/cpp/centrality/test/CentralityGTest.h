/*
 * CentralityGTest.h
 *
 *  Created on: 19.02.2014
 *      Author: cls
 */

#ifndef CENTRALITYGTEST_H_
#define CENTRALITYGTEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class CentralityGTest: public testing::Test {
};

} /* namespace NetworKit */

#endif /* CENTRALITYGTEST_H_ */
