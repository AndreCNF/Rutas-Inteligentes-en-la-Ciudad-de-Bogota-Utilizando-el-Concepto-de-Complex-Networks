/*
 * DynBetweennessGTest.h
 *
 *  Created on: 05.08.2014
 *      Author: ebergamini, cls
 */

#ifndef DYNBETWEENNESSGTEST_H_
#define DYNBETWEENNESSGTEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class DynBetweennessGTest: public testing::Test {
};

} /* namespace NetworKit */

#endif /* DYNBETWEENNESSGTEST_H_ */
