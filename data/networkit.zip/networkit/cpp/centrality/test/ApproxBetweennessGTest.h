/*
 * ApproxBetweennessGTest.h
 *
 *  Created on: 30.06.2014
 *      Author: moritzl
 */

#ifndef APPROXBETWEENNESSGTEST_H_
#define APPROXBETWEENNESSGTEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class ApproxBetweennessGTest : public testing::Test {
public:
	ApproxBetweennessGTest() = default;
	virtual ~ApproxBetweennessGTest() = default;
};

}

#endif /* APPROXBETWEENNESSGTEST_H_ */
