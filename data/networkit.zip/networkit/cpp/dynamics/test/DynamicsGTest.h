/*
 * DynamicsGTest.h
 *
 *  Created on: 24.12.2013
 *      Author: cls
 */

#ifndef DYNAMICSGTEST_H_
#define DYNAMICSGTEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class DynamicsGTest: public testing::Test {
};

} /* namespace NetworKit */

#endif /* DYNAMICSGTEST_H_ */
