/*
 * CliqueGTest.h
 *
 *  Created on: 08.12.2014
 *      Author: henningm
 */

#ifndef CLIQUEGTEST_H_
#define CLIQUEGTEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class CliqueGTest: public testing::Test {
};

} /* namespace NetworKit */

#endif /* CLIQUEGTEST_H_ */
