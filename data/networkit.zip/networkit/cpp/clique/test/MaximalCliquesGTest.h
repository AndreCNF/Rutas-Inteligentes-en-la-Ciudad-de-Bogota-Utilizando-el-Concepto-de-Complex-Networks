#ifndef NOGTEST

#ifndef CLIQUETEST_H_
#define CLIQUETEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class MaximalCliquesGTest: public testing::Test {

};

}

#endif /* CLIQUETEST_H_ */

#endif /* NOGTEST */
