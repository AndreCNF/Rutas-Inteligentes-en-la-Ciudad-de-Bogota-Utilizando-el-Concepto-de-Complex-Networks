/*
 * ConnectedComponentsGTest.h
 *
 *  Created on: Sep 16, 2013
 *      Author: birderon
 */

#ifndef NOGTEST

#ifndef CONNECTEDCOMPONENTSGTEST_H_
#define CONNECTEDCOMPONENTSGTEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class ConnectedComponentsGTest: public testing::Test {
public:
};

} /* namespace NetworKit */
#endif /* CONNECTEDCOMPONENTSGTEST_H_ */

#endif /*NOGTEST */
