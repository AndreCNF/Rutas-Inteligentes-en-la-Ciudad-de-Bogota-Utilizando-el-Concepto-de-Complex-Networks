/*
 * QualityMeasure.cpp
 *
 *  Created on: 10.12.2012
 *      Author: Christian Staudt (christian.staudt@kit.edu)
 */

#include "QualityMeasure.h"

namespace NetworKit {

} /* namespace NetworKit */

