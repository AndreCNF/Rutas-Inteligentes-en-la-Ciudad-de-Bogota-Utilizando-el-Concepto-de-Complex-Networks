/*
 *
 */

#include "LocalCoverEvaluation.h"

NetworKit::LocalCoverEvaluation::LocalCoverEvaluation(const NetworKit::Graph &G, const NetworKit::Cover &C) : G(G), C(C) {

}
