/*
 * CommunityGTest.h
 *
 *  Created on: 27.02.2014
 *      Author: cls
 */

#ifndef COMMUNITYGTEST_H_
#define COMMUNITYGTEST_H_

#include <gtest/gtest.h>

namespace NetworKit {

class CommunityGTest: public testing::Test {
};

} /* namespace NetworKit */

#endif /* COMMUNITYGTEST_H_ */
