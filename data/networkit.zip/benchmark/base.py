class Algo:

	def run(self, G):
		raise Exception("Not implemented")
