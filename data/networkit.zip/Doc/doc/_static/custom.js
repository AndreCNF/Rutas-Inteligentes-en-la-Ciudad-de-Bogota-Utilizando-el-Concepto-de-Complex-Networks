$(document).ready(function() {
  if ($("#fancy-particles").length) {
    particlesJS.load('fancy-particles', '_static/particles.json', null);
  }
});
