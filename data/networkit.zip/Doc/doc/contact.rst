=======
Contact
=======

.. |mailinglist| image:: resources/mailinglist.png

Questions and feedback regarding NetworKit should be addressed to the NetworKit mailing list |mailinglist|. We encourage all users to `register <https://lists.ira.uni-karlsruhe.de/mailman/listinfo/networkit>`_ for the mailing list.

NetworKit is maintained by the `Research Group Parallel Computing <http://parco.iti.kit.edu>`_ of the Institute of Theoretical Informatics at `Karlsruhe Institute of Technology (KIT) <http://www.kit.edu/english/index.php>`_.
