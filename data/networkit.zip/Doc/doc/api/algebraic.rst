networkit.algebraic
===================

.. automodule:: networkit.algebraic
    :members:
    :imported-members:
    :undoc-members:
    :show-inheritance:
