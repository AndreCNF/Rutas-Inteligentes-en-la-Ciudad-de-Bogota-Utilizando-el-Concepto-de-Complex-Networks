networkit.stopwatch
====================

.. automodule:: networkit.stopwatch
    :members:
    :undoc-members:
    :show-inheritance:
