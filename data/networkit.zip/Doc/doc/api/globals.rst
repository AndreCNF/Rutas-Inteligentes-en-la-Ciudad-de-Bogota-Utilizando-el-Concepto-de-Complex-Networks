networkit.globals
==================

.. automodule:: networkit.globals
    :members:
    :imported-members:
    :undoc-members:
    :show-inheritance:
