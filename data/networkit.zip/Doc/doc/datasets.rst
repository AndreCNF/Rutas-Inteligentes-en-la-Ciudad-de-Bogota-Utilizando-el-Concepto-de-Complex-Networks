=========
Data sets
=========

On this page, we provide links to data sets which can be used with NetworKit.

- `10th DIMACS Implementation Challenge (2010-2012) <http://www.cc.gatech.edu/dimacs10/downloads.shtml>`_

- `Stanford Network Analysis Project <http://snap.stanford.edu/>`_

- `The Koblenz Network Collection <http://konect.uni-koblenz.de/>`_
